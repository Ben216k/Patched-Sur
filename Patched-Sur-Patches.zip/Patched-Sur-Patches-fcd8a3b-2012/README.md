# PLEASE IGNORE THIS REPO
## It literally does nothing on it's own.
### You need the updated patcher app to use this.
#### So... please go away.

Patched Sur will soon remove all dependencies from the micropatcher. While I'm not excited to do this, maintaining my own copy of all of the patches is the only way for Patched Sur to support itself as a true patcher.

Starting out, this repo will only have the modification to the USB, but soon branch into a full repo for all of the patches. The reason I am not hosting this on the main Patched-Sur repo is so I could have a separate version for each, so I don't have to release a new version of Patched Sur for an update to the patches.

Right now, a lot of this code is still from the micorpatcher, so note that I am not the magical creator of a lot of this, barrykn (and contributors to the micropatcher) built most of this, so please give a lot of your thanks to him, not me.
